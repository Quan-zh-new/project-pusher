# Sanitized Project Pusher Export

This export is intended for sharing source code without local business data, project state, screenshots, credentials, or local user paths. See `SANITIZATION_REPORT.json` for the exclusion and replacement policy.

To run locally:

```sh
npm install
npm start
```

The application starts with `data/state.example.json`; do not restore a real `data/state.json` into a shared copy.
